let toggleD = localStorage.getItem('darkUser')

const enabledarkmode = ()=>{
  document.body.classList.add('darkActive') 
  localStorage.setItem('darkUser', "enabledarkmode" )   
}

const disabledarkmode = ()=>{
    document.body.classList.remove('darkActive')   
  
  localStorage.setItem('darkUser', null)
}
if(toggleD === 'enabledarkmode'){
  enabledarkmode()
}
const toggleTheme = document.getElementById('toggleTheme')
toggleTheme.addEventListener('click', ()=>{
      toggleD =  localStorage.getItem('darkUser')
        if(toggleD !== 'enabledarkmode'){
          enabledarkmode()
        }
        else {
          disabledarkmode()
        }
})

let posting = []
const add_options = document.querySelector('.add-options')
const addIdea = document.querySelector('.addIdea')

const remove_btn = document.querySelector('.remove-btn')

addIdea.addEventListener('click', ()=>{

    add_options.style.display = 'block'
    add_options.classList.add('openin')
    add_options.classList.remove('closeout')
  
})
function cancelBtn(){
  add_options.classList.add('closeout')
  setTimeout(()=>{
    add_options.style.display = 'none'
  },300)
  
}
remove_btn.addEventListener('click', movedown)


function movedown(){
   add_options.classList.remove('active')
}

let movex = 0;
let downX = 0;

document.addEventListener('touchstart', (e)=>{
  moveX = e.touches[0].clientX;
  
})

document.addEventListener('touchmove', (e)=>{
   downX = e.touches[0].movex
})

document.addEventListener('touchend',()=>{
  
  const allof = downX - moveX 
  if(allof < -80 && add_options.classList.contains('active') ){
    movedown()
  }
  
})
const receive_images = document.getElementById('receive-images')
let imageBase64 = ""

const file_maker = document.getElementById('file-maker')
if(file_maker){
file_maker.addEventListener('change',(event)=>{
  const files  = event.target.files 
   receive_images.innerHTML = ""
   imageBase64 = ""
  if(files.length > 0){
  
      const file = files[0]
      
      const reader = new FileReader()
      reader.onload = function(e){
        
       imageBase64 = e.target.result
       const img = document.createElement('img')
        img.src = imageBase64
        
        img.style.width = '150px'
        
        receive_images.appendChild(img)
      }
      reader.readAsDataURL(file)
    
    
  }
  
  
})
}

let userPosting = []
function loadErOfuplod(){
  
  const uPosting = localStorage.getItem('usposting')
 
 return uPosting ? JSON.parse(uPosting) : []
  
}
const input_text = document.querySelector('.input-text')

const post_btn = document.querySelector('.post-btn')

function  userOfposting(){
  localStorage.setItem('usposting', JSON.stringify(userPosting))
}


let  grid_Posts = document.querySelector('.grid-Posts')
let all_holder = document.querySelector('.all_holder')
let photo_holder = document.querySelector('.photo_holder')
let text_holder = document.querySelector('.text_holder')
let inputValue = []
let image = []


const options_box = document.querySelector('.options_box')

function renderPostt(users){
  let holder1posts = ""
   holder1posts = userPosting.map(users =>  `
    <div class="userPosts">
      <div class="upperLine">
        <span class="user-Profile"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Z"/></svg></span> <span class="user-name">idris mukhtar</span>
    <span class="options-down" onclick="optionsDown('${users.id}')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"/></svg></span>  </div>
     <p class="fromUserText">${users.inputValue}</p>
     <img class="image" id="imagess" src="${users.image}">
     <div class="user-Interference">
       <button class="like-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="m480-120-58-52q-101-91-167-157T150-447.5Q111-500 95.5-544T80-634q0-94 63-157t157-63q52 0 99 22t81 62q34-40 81-62t99-22q94 0 157 63t63 157q0 46-15.5 90T810-447.5Q771-395 705-329T538-172l-58 52Zm0-108q96-86 158-147.5t98-107q36-45.5 50-81t14-70.5q0-60-40-100t-100-40q-47 0-87 26.5T518-680h-76q-15-41-55-67.5T300-774q-60 0-100 40t-40 100q0 35 14 70.5t50 81q36 45.5 98 107T480-228Zm0-273Z"/></svg></button>
       <button class="comment-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-80v-720q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v480q0 33-23.5 56.5T800-240H240L80-80Zm160-320h320v-80H240v80Zm0-120h480v-80H240v80Zm0-120h480v-80H240v80Z"/></svg></button>
       <button class="share-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-120q-66 0-113-47T80-280q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm480 0q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm-480-80q33 0 56.5-23.5T320-280q0-33-23.5-56.5T240-360q-33 0-56.5 23.5T160-280q0 33 23.5 56.5T240-200Zm480 0q33 0 56.5-23.5T800-280q0-33-23.5-56.5T720-360q-33 0-56.5 23.5T640-280q0 33 23.5 56.5T720-200ZM480-364q-32 0-54-22t-22-54q0-32 22-54t54-22q32 0 54 22t22 54q0 32-22 54t-54 22Zm0-196q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T560-720q0-33-23.5-56.5T480-800q-33 0-56.5 23.5T400-720q0 33 23.5 56.5T480-640Zm0-80ZM240-280Zm480 0Z"/></svg></button>
       <button class="save-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120v-640q0-33 23.5-56.5T280-840h400q33 0 56.5 23.5T760-760v640L480-240 200-120Zm80-122 200-86 200 86v-518H280v518Zm0-518h400-400Z"/></svg></button>
         <span id="time">${timeAgo(users.dateString)}</span>
     </div>
    </div>
   
`).join('')

grid_Posts.innerHTML = holder1posts

     
}
function renderPostt2(users){
  let holder2posts = "";
 holder2posts = userPosting.map(users => `
     <div class="userPosts2">

     <p class="fromUserText">${users.inputValue}</p>
     <img class="image" id="imagess" src="${users.image}">
      <div class="upper_Line2">
             <span class="user-Profile"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Z"/></svg></span> <span class="user-name">idris mukhtar</span>
    <span class="options-down2" onclick="optionsDown('${users.id}')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"/></svg></span>  </div>
    
     <div class="user-Interference">
       <button class="like-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="m480-120-58-52q-101-91-167-157T150-447.5Q111-500 95.5-544T80-634q0-94 63-157t157-63q52 0 99 22t81 62q34-40 81-62t99-22q94 0 157 63t63 157q0 46-15.5 90T810-447.5Q771-395 705-329T538-172l-58 52Zm0-108q96-86 158-147.5t98-107q36-45.5 50-81t14-70.5q0-60-40-100t-100-40q-47 0-87 26.5T518-680h-76q-15-41-55-67.5T300-774q-60 0-100 40t-40 100q0 35 14 70.5t50 81q36 45.5 98 107T480-228Zm0-273Z"/></svg></button>
       <button class="comment-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-80v-720q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v480q0 33-23.5 56.5T800-240H240L80-80Zm160-320h320v-80H240v80Zm0-120h480v-80H240v80Zm0-120h480v-80H240v80Z"/></svg></button>
       <button class="share-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-120q-66 0-113-47T80-280q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm480 0q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm-480-80q33 0 56.5-23.5T320-280q0-33-23.5-56.5T240-360q-33 0-56.5 23.5T160-280q0 33 23.5 56.5T240-200Zm480 0q33 0 56.5-23.5T800-280q0-33-23.5-56.5T720-360q-33 0-56.5 23.5T640-280q0 33 23.5 56.5T720-200ZM480-364q-32 0-54-22t-22-54q0-32 22-54t54-22q32 0 54 22t22 54q0 32-22 54t-54 22Zm0-196q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T560-720q0-33-23.5-56.5T480-800q-33 0-56.5 23.5T400-720q0 33 23.5 56.5T480-640Zm0-80ZM240-280Zm480 0Z"/></svg></button>
       <button class="save-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120v-640q0-33 23.5-56.5T280-840h400q33 0 56.5 23.5T760-760v640L480-240 200-120Zm80-122 200-86 200 86v-518H280v518Zm0-518h400-400Z"/></svg></button>
         <span id="time">${timeAgo(users.dateString)}</span>
     </div>
    </div>
 
 `).join('')
 all_holder.innerHTML = holder2posts
}
let use = document.querySelector('.userPosts3')
function renderPostt3(){
photo_holder.innerHTML = userPosting.map(users => `
     <div class="userPosts3">
     <img class="image" id="imagess" src="${users.image}">
      <div class="upper_Line2">
             <span class="user-Profile"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Z"/></svg></span> <span class="user-name">idris mukhtar</span>
    <span class="options-down2" onclick="optionsDown('${users.id}')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"/></svg></span>  </div>
    
     <div class="user-Interference">
       <button class="like-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="m480-120-58-52q-101-91-167-157T150-447.5Q111-500 95.5-544T80-634q0-94 63-157t157-63q52 0 99 22t81 62q34-40 81-62t99-22q94 0 157 63t63 157q0 46-15.5 90T810-447.5Q771-395 705-329T538-172l-58 52Zm0-108q96-86 158-147.5t98-107q36-45.5 50-81t14-70.5q0-60-40-100t-100-40q-47 0-87 26.5T518-680h-76q-15-41-55-67.5T300-774q-60 0-100 40t-40 100q0 35 14 70.5t50 81q36 45.5 98 107T480-228Zm0-273Z"/></svg></button>
       <button class="comment-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-80v-720q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v480q0 33-23.5 56.5T800-240H240L80-80Zm160-320h320v-80H240v80Zm0-120h480v-80H240v80Zm0-120h480v-80H240v80Z"/></svg></button>
       <button class="share-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-120q-66 0-113-47T80-280q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm480 0q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm-480-80q33 0 56.5-23.5T320-280q0-33-23.5-56.5T240-360q-33 0-56.5 23.5T160-280q0 33 23.5 56.5T240-200Zm480 0q33 0 56.5-23.5T800-280q0-33-23.5-56.5T720-360q-33 0-56.5 23.5T640-280q0 33 23.5 56.5T720-200ZM480-364q-32 0-54-22t-22-54q0-32 22-54t54-22q32 0 54 22t22 54q0 32-22 54t-54 22Zm0-196q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T560-720q0-33-23.5-56.5T480-800q-33 0-56.5 23.5T400-720q0 33 23.5 56.5T480-640Zm0-80ZM240-280Zm480 0Z"/></svg></button>
       <button class="save-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120v-640q0-33 23.5-56.5T280-840h400q33 0 56.5 23.5T760-760v640L480-240 200-120Zm80-122 200-86 200 86v-518H280v518Zm0-518h400-400Z"/></svg></button>
         <span id="time">${timeAgo(users.dateString)}</span>
     </div>
    </div>
`).join('')

 
}

function renderPostt4(){
  text_holder.innerHTML = userPosting.map(users =>`
       <div class="userPosts4">

     <p class="fromUserText">${users.inputValue}</p>
      <div class="upper_Line2">
             <span class="user-Profile"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Z"/></svg></span> <span class="user-name">idris mukhtar</span>
    <span class="options-down2" onclick="optionsDown('${users.id}')"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"/></svg></span>  </div>
    
     <div class="user-Interference">
       <button class="like-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="m480-120-58-52q-101-91-167-157T150-447.5Q111-500 95.5-544T80-634q0-94 63-157t157-63q52 0 99 22t81 62q34-40 81-62t99-22q94 0 157 63t63 157q0 46-15.5 90T810-447.5Q771-395 705-329T538-172l-58 52Zm0-108q96-86 158-147.5t98-107q36-45.5 50-81t14-70.5q0-60-40-100t-100-40q-47 0-87 26.5T518-680h-76q-15-41-55-67.5T300-774q-60 0-100 40t-40 100q0 35 14 70.5t50 81q36 45.5 98 107T480-228Zm0-273Z"/></svg></button>
       <button class="comment-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M80-80v-720q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v480q0 33-23.5 56.5T800-240H240L80-80Zm160-320h320v-80H240v80Zm0-120h480v-80H240v80Zm0-120h480v-80H240v80Z"/></svg></button>
       <button class="share-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-120q-66 0-113-47T80-280q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm480 0q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm-480-80q33 0 56.5-23.5T320-280q0-33-23.5-56.5T240-360q-33 0-56.5 23.5T160-280q0 33 23.5 56.5T240-200Zm480 0q33 0 56.5-23.5T800-280q0-33-23.5-56.5T720-360q-33 0-56.5 23.5T640-280q0 33 23.5 56.5T720-200ZM480-364q-32 0-54-22t-22-54q0-32 22-54t54-22q32 0 54 22t22 54q0 32-22 54t-54 22Zm0-196q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T560-720q0-33-23.5-56.5T480-800q-33 0-56.5 23.5T400-720q0 33 23.5 56.5T480-640Zm0-80ZM240-280Zm480 0Z"/></svg></button>
       <button class="save-btn"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120v-640q0-33 23.5-56.5T280-840h400q33 0 56.5 23.5T760-760v640L480-240 200-120Zm80-122 200-86 200 86v-518H280v518Zm0-518h400-400Z"/></svg></button>
         <span id="time">${timeAgo(users.dateString)}</span>
     </div>
    </div>
  
  `).join('')
}

if(post_btn){
post_btn.addEventListener('click', () => {
  inputValue = input_text.value.toLowerCase()
  
  if(inputValue || imageBase64){
    
   // image = img.src
    const dateString = new Date().toISOString()
 userPosting.unshift({
   id: generateId(),
   inputValue: inputValue,
   image: imageBase64,
   dateString
 })
 
 
  }  else {
    
    
  }userOfposting()
  renderPostt()
  renderPostt2()
  renderPostt3()
  renderPostt4()
  cancelBtn()
  input_text.value = '';
  imageBase64 = ""
  receive_images.innerHTML = ""
  
})
}
function generateId() {
  return Date.now() .toString() 
}


userPosting = loadErOfuplod()
 renderPostt()
renderPostt2()
renderPostt3()
renderPostt4()

function optionsDown(postid){
  options_box.style.display = "block"
  
  options_box.innerHTML =
       `  <div class="upperofboxes"><span onclick="removebox()"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="#FFFFFF"><path d="M312-265.33 265.33-312l168-168-168-167L312-693.67l168 168 167-168L693.67-647l-168 167 168 168L647-265.33l-167-168-168 168Z"/></svg></span></div>
    <div class="edit_btn"><span><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M120-120v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm584-528 56-56-56-56-56 56 56 56Z"/></svg>edit </span> </div>
    <div class="delete_btn"> <span 
    onclick="deletePost('${postid}')
    removebox()
    "><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="#FFFFFF"><path d="M267.33-120q-27.5 0-47.08-19.58-19.58-19.59-19.58-47.09V-740H160v-66.67h192V-840h256v33.33h192V-740h-40.67v553.33q0 27-19.83 46.84Q719.67-120 692.67-120H267.33Zm425.34-620H267.33v553.33h425.34V-740Zm-328 469.33h66.66v-386h-66.66v386Zm164 0h66.66v-386h-66.66v386ZM267.33-740v553.33V-740Z"/></svg> delete </s </div>
     `
  
  
  
}


function removebox() {
  options_box.style.display = 'none'
}

function timeAgo(dateString){
  const start = new Date(dateString)
  const now = new Date()
  
  const diffms = now - start
  const  diffMn = Math.floor(diffms / (1000 * 60))
  const diffHours = Math.floor(diffMn / 60)
  const  diffdays = Math.floor(diffHours / 24)
  const diffWeak = Math.floor(diffdays / 7)
  const diffmon = Math.floor(diffWeak / 4.3)
  const diffYear = Math.floor(diffmon / 12)
  
  if(diffdays > 0 )  return ` ${diffdays} day${diffdays !== 1 ?'s' : ''} ago`
   if(diffHours > 0) return ` ${diffHours} hr${diffHours !== 1 ?'s' : ''} ago `
  if(diffMn > 0) return ` ${diffMn} mn${diffMn !== 1 ? 's' : ''} ago `
  if(diffWeak > 0) return `${diffWeak} weak${diffWeak !== 1 ? 's' : '' }ago`
  if(diffmon > 0) return `${diffmon} month${diffmon !== 1 ? 's' : ''}ago`
  if(diffYear > 0) return `${diffYear} Yr${diffYear !== 1 ? 's' : ''}ago`
  return "just now"
userOfposting()

}



function deletePost(usersid) {
  userPosting = userPosting.filter(users => users.id != usersid)
  
  userOfposting()
  renderPostt()
  renderPostt2()
  renderPostt3()
  renderPostt4()
}
// this area is where content page remove happens 
const area_profile = document.querySelector('.area_profile')
const content_Page = document.querySelector('.content_Page')

const home_btn = document.querySelector('.home_btn')

const profile_btn = document.querySelector('.profile_btn')
let svg_pro = document.querySelector(".svg_pro")
let svg_home = document.querySelector(".svg_home")

profile_btn.addEventListener('click',()=>{
  
  if(area_profile){
 area_profile.style.display = 'block'
 svg_pro.classList.add('colorpro')
 svg_home.classList.remove('colorhom')
} 
  content_Page.style.display = 'none'



});
svg_home.classList.add('colorhom')

home_btn.addEventListener('click',()=>{
  
  content_Page.style.display = 'block'
  if(area_profile){
  area_profile.style.display = 'none'
  svg_pro.classList.remove('colorpro')
  svg_home.classList.add('colorhom')
  }
});


function  alls(){
all_holder.style.display = "block" 
photo_holder.style.display = "none"
text_holder.style.display = "none"
}


function  photo(users) {
  all_holder.style.display = "none" 
  photo_holder.style.display = "block"
  text_holder.style.display = "none";
 if(inputValue = true ) {
  use.style.display = "none"
   
 }
  
  
}
function text() {
    all_holder.style.display = "none" 
    photo_holder.style.display = "none"
   text_holder.style.display = "block"
}
let allOfthem_page = document.querySelector(".allOfthem_page")
const signUp_box = document.querySelector('.signUp_box')
const dialog_account = document.getElementById('dialog_account')
const openAccount = document.getElementById("openAccount")
const  backdrop = document.querySelector('.backdrop')
const overlay = document.querySelector('.overlay')


let dhamaadY = 0
let currentY = 0 
let lastPosition = 0
let  isdragging = false 


openAccount.addEventListener('click', ()=>{
 overlay.classList.add('overlayFade')
 dialog_account.classList.add('fure')
 dialog_account.classList.remove('xidh')
  dialog_account.style.display = "block"
  document.body.style.overflow = "hidden"
  //backdrop.style.display = "block"
  overlay.style.display = 'block'
renderAcount()
  dialog_account.style.transform = 'translateY(0)'
  lastPosition = 0;
})
function  takeItAway(){
  dialog_account.classList.add('xidh')
  setTimeout(()=>{
    currentY = 0
  dialog_account.style.transform = 'translateX(0)'
 dialog_account.style.display = "none"   
  },100)
  
  document.body.style.overflow = "auto"
  
  overlay.style.display = 'none'

  
}


/*document.addEventListener('click',function (event){
  if(event.target !== dialog_account && !dialog_account.contains(event.target) && event.target !== openAccount ){
    takeItAway()
  }
}) */

function createsBtn() {
  signUp_box.style.display = "block"
  signUp_box.classList.add('openIn')
  allOfthem_page.style.display = "none"
allOfthem_page.classList.add('come')
allOfthem_page.classList.remove('leave')

  signUp_box.classList.remove('closeOut')
}
function closeSignUp() {
allOfthem_page.classList.add('leave')
  signUp_box.classList.add('closeOut')
  setTimeout(()=>{
  signUp_box.style.display = "none"  
  allOfthem_page.style.display = "block"
  },200)
    

}
const signUp_form = document.getElementById("signUp_form")
const input_Text  = document.querySelector('.input_Text')
const input_Email = document.querySelector('.input_Email')
const show_userErr  = document.getElementById('show_userErr')
const show_emailErr = document.getElementById('show_emailErr')
const show_passwordErr = document.getElementById('show_passwordErr')
const input_password = document.querySelector('.input_password')


signUp_form.addEventListener('submit', (event)=>{
  event.preventDefault()
  let errors  = []
 errors = getSignUpForm(input_Text.value,input_Email.value, input_password.value)  

})

function getSignUpForm(inputText,inputEmail, inputPassword ) {
   let errors  = []
   if(inputText === '' || inputText === null){
    errors.push('username is required ')
    input_Text.classList.add('incorrect')
    show_userErr.innerText = errors;
    
   } 
   let errors1 = []
   if(inputEmail === '' || inputEmail === null){
    errors1.push('email is required ')
    input_Email.classList.add('incorrect')
    show_emailErr.innerText = errors1;
    
   }
   let errors2 = []
   if(inputPassword === '' || inputPassword === null){
    errors2.push('password is required ')
    input_password.classList.add('incorrect')
    show_passwordErr.innerText = errors2;
    
   }
   let errors3 = []
   if(inputPassword.length < 8){
   errors3.push("password must  have  8 characters long ")
   show_passwordErr.innerText = errors3;
   } else {
     show_passwordErr.innerText = "";
   }
  
}

const allinputs = [input_text, input_Email, input_password]

allinputs.forEach(input =>{
  input_Text.addEventListener('input',()=>{
  if(input_Text.classList.contains('incorrect')) {
    input_Text.classList.remove('incorrect')
    show_userErr.innerText = ""
  }
  
    
  })
  input_Email.addEventListener('input',()=>{
  if(input_Email.classList.contains('incorrect')) {
    input_Email.classList.remove('incorrect')
   show_emailErr.innerText = ""
  }
  
    
  })
  input_password.addEventListener('input', () => {
  if (input_password.classList.contains('incorrect')) {
    input_password.classList.remove('incorrect')
    show_passwordErr.innerText = ""
  }
  })

})
const removeHeader = document.getElementById('removeHeader')

function toggleSide(){
  dialog_account.classList.add('active')
  }
function removeDialog(){
  dialog_account.classList.remove('active')
}



dialog_account.addEventListener('touchstart',(e)=>{
    
    dhamaadY = e.touches[0].clientY
    dialog_account.classList.add('animat')
    overlay.style.display = 'block'
    isdragging = true 
    
  dialog_account.style.transition = 'none'
})

dialog_account.addEventListener('touchmove',(e) =>{
  
  if(!isdragging) return;
  const deleter = e.touches[0].clientY - dhamaadY
  overlay.style.display = 'block'
  //dialog_account.style.transition = "0.3s "
  if(deleter > 0) {
    currentY = deleter
    dialog_account.style.transform = `translateY(${deleter}px)`
    overlay.style.display = 'none'
    
  }
  
  
  
})

dialog_account.addEventListener('touchend',  ()=>{
  isdragging = false 
  overlay.style.display = 'block'
  if(currentY > 130){
    takeItAway()
    overlay.style.display = 'none'
   
    document.body.style.overflow = "auto"
  } else {
    
    dialog_account.style.transform = 'translateY(0%)'
    dialog_account.style.transition = "0.3s "
    
    lastPosition = currentY 
    
  }

    
     //overlay.style.display = 'none'
    
   
  
})
function dismiss(){
 overlay.style.display = "none"
  dialog_account.style.display = 'none'
 document.body.style.overflow = "auto"
 
  dialog_account.classList.add('xidh')
  setTimeout(() => {
    dialog_account.style.transform = 'translateY(100%)'
    lastPosition = currentY
  }, 100) 


}
    overlay.addEventListener('click', dismiss)
  let accountUser = userData()
  
  
  
  function randomUUD(id){
    Date.now.toString(36)+Math.random().toString(36).slice(2)
  }
  
  function userData(){
    const userDatas = localStorage.getItem('dataUser')
    
    return userDatas ? JSON.parse(userDatas) : []
  }
  
  function holdUserData(){
    localStorage.setItem('dataUser', JSON.stringify(accountUser))
  }
  function renderAcount(){
    let showAcountsChild = "";
      
      showAcountsChild = accountUser.map(acu => `
      <div class="remove-header"></div>
     <div class="account_switch_off">
       <div class="area_accounts">
         <div class="your_Profile" onclick="openOps()">
           <div class="bothOfThem"><img src="images/idris.jpg" height="30px">
           <span>${acu.userValue}</span>
           </div>
           <span>${acu.emailValue}</span>
         </div>
         <button class="create_acc_btn" onclick="createsBtn()">+ Create an account</button>
       </div>
       <p class="instruction">switch easly your different accounts here and even <span>+create one</span> </p>
       <button class="take_it_away_btn" onclick="takeItAway()">cancel</button>
     </div> 
    `).join('')
    dialog_account.innerHTML += showAcountsChild
    
  }
  const authContainer = document.querySelector('.auth-container')
  
const authForm = document.getElementById('authForm')

const userInpt = document.getElementById('userInpt')

const emailInpt = document.getElementById('emailInpt')

authForm.addEventListener('submit',(event)=>{
  event.preventDefault()
  const userValue = userInpt.value.trim()
   const emailValue = emailInpt.value.trim()
if(!userValue || !emailValue) return;
accountUser.push({
  id: randomUUD(),
  userValue, 
  emailValue
})

renderAcount()
holdUserData()

authContainer.style.display = 'none';

})




function checkAuthUI() {
  if (accountUser.length > 0) {
    authContainer.style.display = 'none'
    renderAcount()
  } else {
    authContainer.style.display = 'flex'
  }
}
checkAuthUI()



document.querySelector('.caution_child').textContent  = `If you delete your account You 
lose all data`;
const personalUsr = document.querySelector('.personalUsr')
function openOps() {
  if(personalUsr.style.display === 'none'){
  personalUsr.style.display = 'block'
  }
}
